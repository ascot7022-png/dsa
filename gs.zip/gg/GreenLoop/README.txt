Task Numbers (Tescode Group - GreenLoop Project)


Manage Product Catalogue - 01
Manage Clients - 02
Manage Inventory - 03
Manage Delivery Agents - 04
Process Orders - 05
Assign Delivery Agents - 06
Reports - 07
Email Notifications - 08