create database GreenLoop;
use GreenLoop;

-- Products table
CREATE TABLE Products (
    product_id INT IDENTITY(1,1) PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    description VARCHAR(100) NULL,
    price DECIMAL(10,2) NOT NULL,
    eco_rating VARCHAR(10) NULL,
    quantity INT NOT NULL DEFAULT 0,
    reorder_level INT NOT NULL DEFAULT 10
);
GO

-- Clients table
CREATE TABLE Clients (
    client_id INT IDENTITY(1,1) PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    contact VARCHAR(15) NULL,
    email VARCHAR(50) NULL,
    address VARCHAR(100) NULL
);
GO

-- DeliveryAgents table
CREATE TABLE DeliveryAgents (
    agent_id INT IDENTITY(1,1) PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    vehicle_no VARCHAR(20) NULL,
    contact VARCHAR(15) NULL
);
GO

-- Orders table
CREATE TABLE Orders (
    order_id INT IDENTITY(1,1) PRIMARY KEY,
    client_id INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    order_date DATE NOT NULL DEFAULT GETDATE(),
    status VARCHAR(20) NOT NULL DEFAULT 'Pending',
    FOREIGN KEY (client_id) REFERENCES Clients(client_id)
);
GO

-- OrderDetails table
CREATE TABLE OrderDetails (
    detail_id INT IDENTITY(1,1) PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    subtotal DECIMAL(10,2) NOT NULL DEFAULT 0,
    FOREIGN KEY (order_id) REFERENCES Orders(order_id),
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);
GO

-- Assignments table
CREATE TABLE Assignments (
    assignment_id INT IDENTITY(1,1) PRIMARY KEY,
    order_id INT NOT NULL,
    agent_id INT NOT NULL,
    assign_date DATE NOT NULL DEFAULT GETDATE(),
    status VARCHAR(20) NOT NULL DEFAULT 'Assigned',
    FOREIGN KEY (order_id) REFERENCES Orders(order_id),
    FOREIGN KEY (agent_id) REFERENCES DeliveryAgents(agent_id)
);
GO


