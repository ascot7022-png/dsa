package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    private static final String SERVER = "localhost";
    private static final String PORT = "1433";
    private static final String DATABASE = "GreenLoop"; // your DB name

    private static Connection conn = null;

    // Keep method synchronized to avoid races when recreating the shared Connection
    public static synchronized Connection getConnection() {
        // If we already have a Connection object, make sure it's still open
        if (conn != null) {
            try {
                if (!conn.isClosed()) return conn; // still valid
                // closed -> we'll fall through to recreate it
                conn = null;
            } catch (SQLException e) {
                // treat any error as requiring a new connection
                conn = null;
            }
        }

        try {
            // Load SQL Server JDBC Driver
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            // ✅ Windows Authentication connection string
            String url = "jdbc:sqlserver://" + SERVER + ":" + PORT +
                    ";databaseName=" + DATABASE +
                    ";integratedSecurity=true;" +
                    "encrypt=true;trustServerCertificate=true;";

            conn = DriverManager.getConnection(url);

            System.out.println("✅ Connected to SQL Server (Windows Auth)!");

        } catch (ClassNotFoundException e) {
            System.out.println("❌ JDBC Driver not found!");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("❌ Connection Failed!");
            e.printStackTrace();
        }

        return conn;
    }

    public static void closeConnection() {
        if (conn != null) {
            try {
                conn.close();
                conn = null;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}