package dao;

import models.DeliveryAgent;
import utils.DBConnection;
import java.sql.*;
import java.util.ArrayList;

public class DeliveryAgentDAO {
    public static boolean addAgent(DeliveryAgent a) {
        String sql = "INSERT INTO DeliveryAgents(name, vehicle_no, contact) VALUES(?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, a.getName());
            ps.setString(2, a.getVehicleNo());
            ps.setString(3, a.getContact());
            return ps.executeUpdate() > 0;
        } catch(SQLException e){ e.printStackTrace(); return false; }
    }

    public static ArrayList<DeliveryAgent> getAllAgents() {
        ArrayList<DeliveryAgent> list = new ArrayList<>();
        String sql = "SELECT * FROM DeliveryAgents";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while(rs.next()) {
                DeliveryAgent a = new DeliveryAgent(
                    rs.getInt("agent_id"),
                    rs.getString("name"),
                    rs.getString("vehicle_no"),
                    rs.getString("contact")
                );
                list.add(a);
            }
        } catch(SQLException e){ e.printStackTrace(); }
        return list;
    }
}