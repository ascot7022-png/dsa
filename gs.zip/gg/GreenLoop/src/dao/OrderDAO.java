package dao;

import models.Order;
import utils.DBConnection;
import java.sql.*;
import java.util.ArrayList;

public class OrderDAO {
    public static boolean addOrder(Order o) {
        String sql = "INSERT INTO Orders(client_id, total_amount, status) VALUES(?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, o.getClientId());
            ps.setDouble(2, o.getTotalAmount());
            ps.setString(3, o.getStatus());
            int affected = ps.executeUpdate();
            if (affected > 0) {
                ResultSet rs = ps.getGeneratedKeys();
                if(rs.next()) o.setOrderId(rs.getInt(1));
                return true;
            }
            return false;
        } catch(SQLException e){ e.printStackTrace(); return false; }
    }

    public static ArrayList<Order> getAllOrders() {
        ArrayList<Order> list = new ArrayList<>();
        String sql = "SELECT * FROM Orders";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while(rs.next()) {
                Order o = new Order(
                    rs.getInt("order_id"),
                    rs.getInt("client_id"),
                    rs.getDouble("total_amount"),
                    rs.getTimestamp("order_date"),
                    rs.getString("status")
                );
                list.add(o);
            }
        } catch(SQLException e){ e.printStackTrace(); }
        return list;
    }

    public static ArrayList<Object[]> getMonthlyRevenueSummary() {
        ArrayList<Object[]> summary = new ArrayList<>();
        String sql = "SELECT YEAR(order_date) AS yr, MONTH(order_date) AS mo, SUM(total_amount) AS revenue " +
                     "FROM Orders GROUP BY YEAR(order_date), MONTH(order_date) " +
                     "ORDER BY yr DESC, mo DESC";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while(rs.next()) {
                summary.add(new Object[]{
                    rs.getInt("yr"),
                    rs.getInt("mo"),
                    rs.getDouble("revenue")
                });
            }
        } catch(SQLException e){ e.printStackTrace(); }
        return summary;
    }
}