package dao;

import models.Assignment;
import utils.DBConnection;
import java.sql.*;
import java.util.ArrayList;

public class AssignmentDAO {
    public static boolean addAssignment(Assignment a) {
        String sql = "INSERT INTO Assignments(order_id, agent_id, status) VALUES(?,?,?)";
        try(Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, a.getOrderId());
            ps.setInt(2, a.getAgentId());
            ps.setString(3, a.getStatus());
            int affected = ps.executeUpdate();
            if(affected>0){
                ResultSet rs = ps.getGeneratedKeys();
                if(rs.next()) a.setAssignmentId(rs.getInt(1));
                return true;
            }
            return false;
        } catch(SQLException e){ e.printStackTrace(); return false; }
    }

    public static ArrayList<Assignment> getAllAssignments() {
        ArrayList<Assignment> list = new ArrayList<>();
        String sql = "SELECT * FROM Assignments";
        try(Connection conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)) {
            while(rs.next()){
                Assignment a = new Assignment(
                    rs.getInt("assignment_id"),
                    rs.getInt("order_id"),
                    rs.getInt("agent_id"),
                    rs.getTimestamp("assign_date"),
                    rs.getString("status")
                );
                list.add(a);
            }
        } catch(SQLException e){ e.printStackTrace(); }
        return list;
    }
}