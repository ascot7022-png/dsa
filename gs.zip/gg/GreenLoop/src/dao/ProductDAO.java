package dao;

import models.Product;
import utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;

public class ProductDAO {

    public static boolean addProduct(Product p) {
        String sql = "INSERT INTO Products(name, description, price, eco_rating, quantity, reorder_level) VALUES(?,?,?,?,?,?)";
        try(Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, p.getName());
            ps.setString(2, p.getDescription());
            ps.setDouble(3, p.getPrice());
            ps.setString(4, p.getEcoRating());
            ps.setInt(5, p.getQuantity());
            ps.setInt(6, p.getReorderLevel());

            int affected = ps.executeUpdate();
            if(affected > 0) {
                ResultSet rs = ps.getGeneratedKeys();
                if(rs.next()) p.setProductId(rs.getInt(1));
                return true;
            }
            return false;
        } catch(SQLException e) { e.printStackTrace(); return false; }
    }

    public static ArrayList<Product> getAllProducts() {
        ArrayList<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM Products";
        try(Connection conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)) {

            while(rs.next()) {
                Product p = new Product(
                        rs.getInt("product_id"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getString("eco_rating"),
                        rs.getInt("quantity"),
                        rs.getInt("reorder_level")
                );
                list.add(p);
            }

        } catch(SQLException e){ e.printStackTrace(); }
        return list;
    }

    // ✅ New: get Product by ID
    public static Product getProductById(int id) {
        String sql = "SELECT * FROM Products WHERE product_id=?";
        try(Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if(rs.next()) {
                return new Product(
                        rs.getInt("product_id"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getString("eco_rating"),
                        rs.getInt("quantity"),
                        rs.getInt("reorder_level")
                );
            }
        } catch(SQLException e){ e.printStackTrace(); }
        return null;
    }

    public static ArrayList<Product> getLowStockProducts() {
        ArrayList<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM Products WHERE quantity <= reorder_level ORDER BY quantity ASC";
        try(Connection conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)) {

            while(rs.next()) {
                Product p = new Product(
                        rs.getInt("product_id"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getString("eco_rating"),
                        rs.getInt("quantity"),
                        rs.getInt("reorder_level")
                );
                list.add(p);
            }
        } catch(SQLException e){ e.printStackTrace(); }
        return list;
    }
}