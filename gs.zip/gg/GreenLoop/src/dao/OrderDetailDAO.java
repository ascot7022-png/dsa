package dao;

import models.OrderDetail;
import utils.DBConnection;

import java.sql.*;

public class OrderDetailDAO {

    public static boolean addOrderDetail(OrderDetail od) {
        String sql = "INSERT INTO OrderDetails(order_id, product_id, quantity, subtotal) VALUES(?,?,?,?)";
        try(Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, od.getOrderId());
            ps.setInt(2, od.getProductId());
            ps.setInt(3, od.getQuantity());
            ps.setDouble(4, od.getSubtotal());  // make sure subtotal is never null

            int affected = ps.executeUpdate();
            if(affected > 0) {
                ResultSet rs = ps.getGeneratedKeys();
                if(rs.next()) od.setDetailId(rs.getInt(1));
                return true;
            }
            return false;

        } catch(SQLException e) { e.printStackTrace(); return false; }
    }
}