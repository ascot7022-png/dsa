package dao;

import models.Client;
import utils.DBConnection;
import java.sql.*;
import java.util.ArrayList;

public class ClientDAO {
    public static boolean addClient(Client c) {
        String sql = "INSERT INTO Clients(name, contact, email, address) VALUES(?,?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, c.getName());
            ps.setString(2, c.getContact());
            ps.setString(3, c.getEmail());
            ps.setString(4, c.getAddress());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public static ArrayList<Client> getAllClients() {
        ArrayList<Client> list = new ArrayList<>();
        String sql = "SELECT * FROM Clients";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while(rs.next()) {
                Client c = new Client(
                    rs.getInt("client_id"),
                    rs.getString("name"),
                    rs.getString("contact"),
                    rs.getString("email"),
                    rs.getString("address")
                );
                list.add(c);
            }
        } catch(SQLException e) { e.printStackTrace(); }
        return list;
    }
}