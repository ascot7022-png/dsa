package views;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import dao.OrderDAO;
import dao.ProductDAO;
import models.Order;
import models.Product;
import java.awt.*;
import java.util.ArrayList;

public class ReportsForm extends JFrame {

    private JTable tableRevenue;
    private JTable tableLowStock;
    private DefaultTableModel revenueModel;
    private DefaultTableModel lowStockModel;
    private JLabel lblTotalRevenue;
    private JLabel lblLowStockCount;

    public ReportsForm() {
        setTitle("Monthly Sales & Inventory Reports");
        setSize(900,520);
        setLayout(new BorderLayout(8, 8));

        JPanel headerPanel = new JPanel(new GridLayout(1, 2, 8, 8));
        lblTotalRevenue = new JLabel("Total revenue: LKR 0.00");
        lblLowStockCount = new JLabel("Low-stock products: 0");
        lblTotalRevenue.setFont(lblTotalRevenue.getFont().deriveFont(Font.BOLD, 14f));
        lblLowStockCount.setFont(lblLowStockCount.getFont().deriveFont(Font.BOLD, 14f));
        headerPanel.add(lblTotalRevenue);
        headerPanel.add(lblLowStockCount);
        add(headerPanel, BorderLayout.NORTH);

        revenueModel = new DefaultTableModel(new String[]{"Year","Month","Revenue"},0);
        tableRevenue = new JTable(revenueModel);
        JScrollPane revenueScroll = new JScrollPane(tableRevenue);
        revenueScroll.setBorder(BorderFactory.createTitledBorder("Monthly Revenue Summary"));

        lowStockModel = new DefaultTableModel(new String[]{"Product ID","Name","Quantity","Reorder Level"},0);
        tableLowStock = new JTable(lowStockModel);
        JScrollPane lowStockScroll = new JScrollPane(tableLowStock);
        lowStockScroll.setBorder(BorderFactory.createTitledBorder("Low-Stock Alerts"));

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, revenueScroll, lowStockScroll);
        splitPane.setResizeWeight(0.5);
        add(splitPane, BorderLayout.CENTER);

        loadReport();

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void loadReport() {
        loadRevenueSummary();
        loadLowStockAlerts();
    }

    private void loadRevenueSummary() {
        ArrayList<Object[]> summary = OrderDAO.getMonthlyRevenueSummary();
        revenueModel.setRowCount(0);
        double totalRevenue = 0;
        for (Object[] row : summary) {
            int year = (int) row[0];
            int month = (int) row[1];
            double revenue = (double) row[2];
            revenueModel.addRow(new Object[]{year, month, String.format("LKR %,.2f", revenue)});
            totalRevenue += revenue;
        }
        lblTotalRevenue.setText(String.format("Total revenue: LKR %,.2f", totalRevenue));
    }

    private void loadLowStockAlerts() {
        ArrayList<Product> lowStock = ProductDAO.getLowStockProducts();
        lowStockModel.setRowCount(0);
        for (Product p : lowStock) {
            lowStockModel.addRow(new Object[]{p.getProductId(), p.getName(), p.getQuantity(), p.getReorderLevel()});
        }
        lblLowStockCount.setText("Low-stock products: " + lowStock.size());
    }
}