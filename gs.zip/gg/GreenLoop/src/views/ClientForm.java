package views;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import dao.ClientDAO;
import models.Client;
import java.awt.*;
import java.util.ArrayList;

public class ClientForm extends JFrame {

    JTextField txtName, txtContact, txtEmail, txtAddress;
    JTable table;
    DefaultTableModel model;

    public ClientForm() {
        setTitle("Manage Clients");
        setSize(700,400);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new GridLayout(2,4));
        txtName = new JTextField(); txtContact = new JTextField();
        txtEmail = new JTextField(); txtAddress = new JTextField();

        topPanel.add(new JLabel("Name:")); topPanel.add(txtName);
        topPanel.add(new JLabel("Contact:")); topPanel.add(txtContact);
        topPanel.add(new JLabel("Email:")); topPanel.add(txtEmail);
        topPanel.add(new JLabel("Address:")); topPanel.add(txtAddress);

        add(topPanel, BorderLayout.NORTH);

        table = new JTable();
        model = new DefaultTableModel(new String[]{"ID","Name","Contact","Email","Address"},0);
        table.setModel(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JButton btnAdd = new JButton("Add");
        JPanel btnPanel = new JPanel(); btnPanel.add(btnAdd);
        add(btnPanel, BorderLayout.SOUTH);

        loadTable();

        btnAdd.addActionListener(e -> {
            try {
                Client c = new Client();
                c.setName(txtName.getText());
                c.setContact(txtContact.getText());
                c.setEmail(txtEmail.getText());
                c.setAddress(txtAddress.getText());
                boolean added = ClientDAO.addClient(c);
                if(added){
                    loadTable();
                    txtName.setText(""); txtContact.setText(""); txtEmail.setText(""); txtAddress.setText("");
                }
            } catch(Exception ex){
                JOptionPane.showMessageDialog(this,"Invalid input");
            }
        });

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void loadTable() {
        ArrayList<Client> list = ClientDAO.getAllClients();
        model.setRowCount(0);
        for(Client c : list){
            model.addRow(new Object[]{c.getClientId(), c.getName(), c.getContact(), c.getEmail(), c.getAddress()});
        }
    }
}