package views;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import dao.ProductDAO;
import models.Product;
import java.awt.*;
import java.util.ArrayList;

public class ProductForm extends JFrame {

    JTextField txtName, txtDesc, txtPrice, txtEco, txtQty, txtReorder;
    JTable table;
    DefaultTableModel model;

    public ProductForm() {
        setTitle("Manage Products");
        setSize(750, 400);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new GridLayout(2,6));
        txtName = new JTextField(); txtDesc = new JTextField(); txtPrice = new JTextField();
        txtEco = new JTextField(); txtQty = new JTextField(); txtReorder = new JTextField();

        topPanel.add(new JLabel("Name:")); topPanel.add(txtName);
        topPanel.add(new JLabel("Description:")); topPanel.add(txtDesc);
        topPanel.add(new JLabel("Price:")); topPanel.add(txtPrice);
        topPanel.add(new JLabel("Eco Rating:")); topPanel.add(txtEco);
        topPanel.add(new JLabel("Quantity:")); topPanel.add(txtQty);
        topPanel.add(new JLabel("Reorder Level:")); topPanel.add(txtReorder);

        add(topPanel, BorderLayout.NORTH);

        table = new JTable();
        model = new DefaultTableModel(new String[]{"ID","Name","Desc","Price","Eco","Qty","Reorder"},0);
        table.setModel(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel btnPanel = new JPanel();
        JButton btnAdd = new JButton("Add"); btnPanel.add(btnAdd);
        JButton btnUpdate = new JButton("Update"); btnPanel.add(btnUpdate);
        JButton btnDelete = new JButton("Delete"); btnPanel.add(btnDelete);
        add(btnPanel, BorderLayout.SOUTH);

        loadTable();

        btnAdd.addActionListener(e -> {
            try {
                Product p = new Product();
                p.setName(txtName.getText());
                p.setDescription(txtDesc.getText());
                p.setPrice(Double.parseDouble(txtPrice.getText()));
                p.setEcoRating(txtEco.getText());
                p.setQuantity(Integer.parseInt(txtQty.getText()));
                p.setReorderLevel(Integer.parseInt(txtReorder.getText()));
                boolean added = ProductDAO.addProduct(p);
                if(added) loadTable();
            } catch(Exception ex) {
                JOptionPane.showMessageDialog(this,"Invalid input");
            }
        });

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void loadTable() {
        ArrayList<Product> list = ProductDAO.getAllProducts();
        model.setRowCount(0);
        for(Product p : list){
            model.addRow(new Object[]{p.getProductId(), p.getName(), p.getDescription(), p.getPrice(), p.getEcoRating(), p.getQuantity(), p.getReorderLevel()});
        }
    }
}