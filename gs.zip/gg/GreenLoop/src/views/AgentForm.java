package views;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import dao.DeliveryAgentDAO;
import models.DeliveryAgent;
import java.awt.*;
import java.util.ArrayList;

public class AgentForm extends JFrame {

    JTextField txtName, txtVehicle, txtContact;
    JTable table;
    DefaultTableModel model;

    public AgentForm() {
        setTitle("Manage Delivery Agents");
        setSize(700,400);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new FlowLayout());
        txtName = new JTextField(10);
        txtVehicle = new JTextField(8);
        txtContact = new JTextField(10);
        JButton btnAdd = new JButton("Add");

        topPanel.add(new JLabel("Name:"));
        topPanel.add(txtName);
        topPanel.add(new JLabel("Vehicle No:"));
        topPanel.add(txtVehicle);
        topPanel.add(new JLabel("Contact:"));
        topPanel.add(txtContact);
        topPanel.add(btnAdd);

        add(topPanel, BorderLayout.NORTH);

        table = new JTable();
        model = new DefaultTableModel(new String[]{"ID","Name","Vehicle","Contact"},0);
        table.setModel(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        loadTable();

        btnAdd.addActionListener(e -> addAgent());

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void addAgent() {
        try {
            DeliveryAgent a = new DeliveryAgent();
            a.setName(txtName.getText());
            a.setVehicleNo(txtVehicle.getText());
            a.setContact(txtContact.getText());

            boolean added = DeliveryAgentDAO.addAgent(a);
            if(added){
                JOptionPane.showMessageDialog(this,"Agent added successfully");
                txtName.setText(""); txtVehicle.setText(""); txtContact.setText("");
                loadTable();
            } else {
                JOptionPane.showMessageDialog(this,"Failed to add agent");
            }
        } catch(Exception ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,"Error adding agent");
        }
    }

    private void loadTable() {
        ArrayList<DeliveryAgent> list = DeliveryAgentDAO.getAllAgents();
        model.setRowCount(0); // clear table
        for(DeliveryAgent a : list){
            model.addRow(new Object[]{a.getAgentId(), a.getName(), a.getVehicleNo(), a.getContact()});
        }
    }
}