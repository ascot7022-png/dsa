package views;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import dao.ClientDAO;
import dao.OrderDAO;
import dao.OrderDetailDAO;
import models.Client;
import models.Order;
import models.OrderDetail;
import java.awt.*;
import java.util.ArrayList;

public class OrderForm extends JFrame {

    JComboBox<Client> cbClients;
    JTable tableOrders;
    JTextField txtProductId, txtQuantity;
    DefaultTableModel model;

    public OrderForm() {
        setTitle("Manage Orders");
        setSize(800,500);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new FlowLayout());
        cbClients = new JComboBox<>();
        loadClients();
        topPanel.add(new JLabel("Select Client:"));
        topPanel.add(cbClients);

        txtProductId = new JTextField(5);
        txtQuantity = new JTextField(5);
        JButton btnAddDetail = new JButton("Add Product");
        topPanel.add(new JLabel("Product ID:"));
        topPanel.add(txtProductId);
        topPanel.add(new JLabel("Quantity:"));
        topPanel.add(txtQuantity);
        topPanel.add(btnAddDetail);

        add(topPanel, BorderLayout.NORTH);

        tableOrders = new JTable();
        model = new DefaultTableModel(new String[]{"Product ID","Quantity","Subtotal"},0);
        tableOrders.setModel(model);
        add(new JScrollPane(tableOrders), BorderLayout.CENTER);

        JButton btnCreateOrder = new JButton("Create Order");
        add(btnCreateOrder, BorderLayout.SOUTH);

        btnAddDetail.addActionListener(e -> addDetail());
        btnCreateOrder.addActionListener(e -> createOrder());

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void loadClients() {
        ArrayList<Client> list = ClientDAO.getAllClients();
        for(Client c : list) cbClients.addItem(c);
    }

    private void addDetail() {
        try {
            int pid = Integer.parseInt(txtProductId.getText());
            int qty = Integer.parseInt(txtQuantity.getText());
            double subtotal = qty * 10; // Replace 10 with real product price
            model.addRow(new Object[]{pid, qty, subtotal});
        } catch(Exception ex) {
            JOptionPane.showMessageDialog(this,"Invalid input");
        }
    }

    private void createOrder() {
        try {
            Client c = (Client) cbClients.getSelectedItem();
            if(c==null) return;
            double total = 0;
            for(int i=0;i<model.getRowCount();i++) total += (double) model.getValueAt(i,2);

            Order o = new Order();
            o.setClientId(c.getClientId());
            o.setTotalAmount(total);
            o.setStatus("Pending");
            OrderDAO.addOrder(o);

            for(int i=0;i<model.getRowCount();i++){
                OrderDetail od = new OrderDetail();
                od.setOrderId(o.getOrderId());
                od.setProductId((int)model.getValueAt(i,0));
                od.setQuantity((int)model.getValueAt(i,1));
                od.setSubtotal((double)model.getValueAt(i,2));
                OrderDetailDAO.addOrderDetail(od);
            }
            JOptionPane.showMessageDialog(this,"Order created successfully");
            model.setRowCount(0);
        } catch(Exception ex){ ex.printStackTrace(); }
    }
}