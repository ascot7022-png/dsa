package views;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    public MainFrame() {
        setTitle("GreenLoop Management");
        setSize(600, 400);
        setLayout(new FlowLayout());

        JButton btnProducts = new JButton("Products");
        JButton btnClients = new JButton("Clients");
        JButton btnOrders = new JButton("Orders");
        JButton btnAgents = new JButton("Delivery Agents");
        JButton btnAssignments = new JButton("Assignments");
        JButton btnReports = new JButton("Reports");

        add(btnProducts);
        add(btnClients);
        add(btnOrders);
        add(btnAgents);
        add(btnAssignments);
        add(btnReports);

        btnProducts.addActionListener(e -> new ProductForm());
        btnClients.addActionListener(e -> new ClientForm());
        btnOrders.addActionListener(e -> new OrderForm());
        btnAgents.addActionListener(e -> new AgentForm());
        btnAssignments.addActionListener(e -> new AssignmentForm());
        btnReports.addActionListener(e -> new ReportsForm());

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // center on screen
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame());
    }
}