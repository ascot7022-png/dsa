package views;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import dao.OrderDAO;
import dao.DeliveryAgentDAO;
import dao.AssignmentDAO;
import models.Order;
import models.DeliveryAgent;
import models.Assignment;
import java.awt.*;
import java.util.ArrayList;

public class AssignmentForm extends JFrame {

    JComboBox<Order> cbOrders;
    JComboBox<DeliveryAgent> cbAgents;
    JTable tableAssignments;
    DefaultTableModel model;

    public AssignmentForm() {
        setTitle("Assign Delivery Agents");
        setSize(700,400);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new FlowLayout());
        cbOrders = new JComboBox<>();
        cbAgents = new JComboBox<>();
        JButton btnAssign = new JButton("Assign");

        loadOrders(); loadAgents();

        topPanel.add(new JLabel("Select Order:"));
        topPanel.add(cbOrders);
        topPanel.add(new JLabel("Select Agent:"));
        topPanel.add(cbAgents);
        topPanel.add(btnAssign);

        add(topPanel, BorderLayout.NORTH);

        tableAssignments = new JTable();
        model = new DefaultTableModel(new String[]{"Assignment ID","Order ID","Agent ID","Status"},0);
        tableAssignments.setModel(model);
        add(new JScrollPane(tableAssignments), BorderLayout.CENTER);

        btnAssign.addActionListener(e -> assignDelivery());

        loadTable();

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void loadOrders() {
        ArrayList<Order> list = OrderDAO.getAllOrders();
        for(Order o : list) cbOrders.addItem(o);
    }

    private void loadAgents() {
        ArrayList<DeliveryAgent> list = DeliveryAgentDAO.getAllAgents();
        for(DeliveryAgent a : list) cbAgents.addItem(a);
    }

    private void assignDelivery() {
        try {
            Order o = (Order) cbOrders.getSelectedItem();
            DeliveryAgent a = (DeliveryAgent) cbAgents.getSelectedItem();
            if(o==null || a==null) return;

            Assignment as = new Assignment();
            as.setOrderId(o.getOrderId());
            as.setAgentId(a.getAgentId());
            as.setStatus("Assigned");
            AssignmentDAO.addAssignment(as);

            JOptionPane.showMessageDialog(this,"Delivery Assigned");
            loadTable();
        } catch(Exception ex){ ex.printStackTrace(); }
    }

    private void loadTable() {
        ArrayList<Assignment> list = AssignmentDAO.getAllAssignments();
        model.setRowCount(0);
        for(Assignment a : list)
            model.addRow(new Object[]{a.getAssignmentId(), a.getOrderId(), a.getAgentId(), a.getStatus()});
    }
}