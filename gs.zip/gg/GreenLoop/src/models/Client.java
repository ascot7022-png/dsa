package models;

public class Client {
    private int clientId;
    private String name, contact, email, address;

    public Client() {}

    public Client(int clientId, String name, String contact, String email, String address) {
        this.clientId = clientId;
        this.name = name;
        this.contact = contact;
        this.email = email;
        this.address = address;
    }

    // Getters & Setters
    public int getClientId() { return clientId; }
    public void setClientId(int clientId) { this.clientId = clientId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    @Override
    public String toString() {
        return name + " (ID: " + clientId + ")";
    }
}