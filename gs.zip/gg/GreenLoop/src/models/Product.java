package models;

public class Product {
    private int productId;
    private String name;
    private String description;
    private double price;
    private String ecoRating;
    private int quantity;
    private int reorderLevel;

    // Constructor
    public Product() {}

    public Product(int productId, String name, String description, double price, String ecoRating, int quantity, int reorderLevel) {
        this.productId = productId;
        this.name = name;
        this.description = description;
        this.price = price;
        this.ecoRating = ecoRating;
        this.quantity = quantity;
        this.reorderLevel = reorderLevel;
    }

    // Getters and Setters
    public int getProductId() { return productId; }
    public void setProductId(int productId) { this.productId = productId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    public String getEcoRating() { return ecoRating; }
    public void setEcoRating(String ecoRating) { this.ecoRating = ecoRating; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public int getReorderLevel() { return reorderLevel; }
    public void setReorderLevel(int reorderLevel) { this.reorderLevel = reorderLevel; }
}