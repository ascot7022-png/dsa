package models;

import java.util.Date;

public class Assignment {
    private int assignmentId;
    private int orderId;
    private int agentId;
    private Date assignDate;
    private String status;

    public Assignment() {}

    public Assignment(int assignmentId, int orderId, int agentId, Date assignDate, String status) {
        this.assignmentId = assignmentId;
        this.orderId = orderId;
        this.agentId = agentId;
        this.assignDate = assignDate;
        this.status = status;
    }

    // Getters & Setters
    public int getAssignmentId() { return assignmentId; }
    public void setAssignmentId(int assignmentId) { this.assignmentId = assignmentId; }
    public int getOrderId() { return orderId; }
    public void setOrderId(int orderId) { this.orderId = orderId; }
    public int getAgentId() { return agentId; }
    public void setAgentId(int agentId) { this.agentId = agentId; }
    public java.util.Date getAssignDate() { return assignDate; }
    public void setAssignDate(java.util.Date assignDate) { this.assignDate = assignDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}