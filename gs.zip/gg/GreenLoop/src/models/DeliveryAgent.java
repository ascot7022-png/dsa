package models;

public class DeliveryAgent {
    private int agentId;
    private String name, vehicleNo, contact;

    public DeliveryAgent() {}

    public DeliveryAgent(int agentId, String name, String vehicleNo, String contact) {
        this.agentId = agentId;
        this.name = name;
        this.vehicleNo = vehicleNo;
        this.contact = contact;
    }

    // Getters & Setters
    public int getAgentId() { return agentId; }
    public void setAgentId(int agentId) { this.agentId = agentId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getVehicleNo() { return vehicleNo; }
    public void setVehicleNo(String vehicleNo) { this.vehicleNo = vehicleNo; }
    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }

    @Override
    public String toString() {
        return name + " (" + vehicleNo + ")";
    }
}